| Version | Change |
|---|---|
| 0.11 | fix problem with logging |
| 0.10 | Clean up error in supervisor for access to devices |
| 0.7  | Support new Addon API |
| 0.6  | logs are displayed in ingress |
| 0.4  | corrected error preventing start on raspi |
| 0.3  | Initial release|
| 0.2  | Further testing|
| 0.1  | initial Testing |
