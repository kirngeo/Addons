| Version | Change |
|---|---|
| 0.14 | Add nvme0n1p1 |
| 0.13 | cleanup error in supervisor for device access with full access |
| 0.11 | removing support for deprecated non-protected mode, and increasing to sec level 6! |
| 0.10 | Support new Addon API |
| 0.9 | Support for Raspian |
| 0.8 | Do not run on startup |
| 0.7 | Incresed security to absolute maximum because, why not? |
| 0.6 | Testing increased security |
| 0.4 | Improving security |
| 0.3 | Supporting odroid |
| 0.2 | fixed problem with not mounting partition correctly |
| 0.1 | initial release |
