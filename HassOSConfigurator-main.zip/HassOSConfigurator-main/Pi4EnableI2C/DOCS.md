No configuration required.  If problems are encountered please get all "Karen" in the forums and make sure to display attitude, because developers love that.  Alternatively, you can provide a log and tell us the problem, what you did, the model of your device, and what happened differently than what you expected.

Support is provided on the Home Assistant Community forums, [here](https://community.home-assistant.io/t/hassos-i2c-configurator/264167)

Just hit the start button and observe the logs. Perform 2- pull-the-plug restart after starting to ensure it takes effect.  The first restart will emplace files.  The second will activate I2C.  You will see a message in the logs that I2C was found after the 2nd restart. You may uninstall the Add-On when complete. 
