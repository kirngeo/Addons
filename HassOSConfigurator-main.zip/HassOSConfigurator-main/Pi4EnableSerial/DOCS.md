No configuration required.  If problems are encountered please get all "Karen" in the forums and make sure to display attitude, because developers love that.  Alternatively, you can provide a log and tell us the problem, what you did, the model of your device, and what happened differently than what you expected.

Support is provided on the Home Assistant Community forums, [here](https://community.home-assistant.io/t/add-on-hassos-serial-configurator/264169).

Just hit the start button and observe the logs. Perform a pull-the-plug restart after starting to ensure it takes effect. You may uninstall the Add-On when complete. 
