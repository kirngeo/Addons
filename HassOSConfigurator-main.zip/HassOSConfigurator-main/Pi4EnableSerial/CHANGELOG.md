| Version | Change |
|---|---|
| 0.5 | Cleanup error in supervisor |
| 0.4 | Support new Addon API |
| 0.3 | Improving messages|
| 0.2 | Improving security|
| 0.1 | initial release |
