| Version | Change                                                    |
|---------|-----------------------------------------------------------|
| 0.9.3   | Check if running in 'protection mode'                     |
| 0.9.2b  | Add skip/success messages and obviously dummy default key |
| 0.9.1a  | Fix for changes in HAOS docker. Fix for mmcblk1p1         |
| 0.9     | Support for mmcblk1p1                                     |
| 0.7     | Support new Addon API                                     |
| 0.6     | Support for x86                                           |
| 0.5     | Incresed security to absolute maximum because, why not?   |
| 0.4     | fixed docker error with cache                             |
| 0.3     | Supporting odroid                                         |
| 0.2     | Improving security rating                                 |
| 0.1     | initial release                                           |
